const path = require('path');
const fs = require('fs');
const request = require('request')
require('dotenv');
const homePage = (req, res) => {
    filePath = path.join(__dirname, '..', 'public', 'index.html');
    console.log('jjjjjjjjjjjjjjjjjjjjj');

    fs.readFile(filePath, (err, file) => {
        if (err) {
            res.writeHead(500, { "content-Type": "text/html" });
            res.end("<h1>internal error</h1>")
        } else {
            res.writeHead(200, { "content-Type": "text/html" });
            res.end(file);
        }
    })

}
const publicPage = (req, res) => {
    const endpoint = req.url;
    const extantion = path.extname(endpoint).split('.')[1];
    console.log(extantion, 545454545455454545454);

    const pathFile = path.join(__dirname, '..', ...endpoint.split('/'));
    const contantType = {
        html: 'text/html',
        css: 'text/css',
        js: 'text/javascript',
        json: 'application/json',
    };

    fs.readFile(pathFile, (error, file) => {
        if (error) {
            res.writeHead(500, {
                'content-type': 'text/html',
            });
            res.end('<h1>Internal Server Error</h1>');
        } else {
            res.writeHead(200, {
                'content-type': contantType[extantion],
            });
            res.end(file);
        }
    });
}
//////////2. comm server with api /////////////////////
const handleSearch = (req, res) => {
    //////////server collect the data that it special this endpiont(/search)===> data from input
    let searchData = '';
    req.on('data', (chunk) => {//chuck this => the data that it is i need it
        searchData += chunk;
    })
    req.on('end', () => {
        console.log('end');

    });
    const options = {
        method: "GET",
        url: `http://api.giphy.com/v1/gifs/search?q=${searchData}&api_key=${process.env.API_KEY}&limit=`
    }//http://api.giphy.com/v1/gifs/search?q=cat&api_key=VnbiCbjbRq3pdWck8JHY9ptAPsbaCbZP&limit=2
    /////////here the server that it comm with api to find the data req that it inside input and this req when return into server convert to res ==>is json(object)
    request(options, (err, response, body) => {
        if (err) {
            // res.writeHead(404, { "content-Type": "text/html" });
            // res.end('error client');
            console.log('error in client');
            
        } else {
            res.writeHead(200, { "content-Type": "application/json" });
            res.end(body)
        }
    })
}
const pageNotFound = (req, res) => {
    filePath = path.join(__dirname, '..', 'public', 'pagenotfound.html');
    fs.readFile(filePath, (err, file) => {
        if (err) {
            res.writeHead(500, { "content-Type": "text/html" });
            res.end("<h1>internal error</h1>")
        } else {
            res.writeHead(404, { "content-Type": "text/html" });
            res.end(file);
        }
    })

}

module.exports = { homePage, publicPage, handleSearch, pageNotFound }