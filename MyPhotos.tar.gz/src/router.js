const handler = require('./handler');
const router = (req, res) => {
    if (req.url == '/') {
        handler.homePage(req, res);
    } else if (req.url.includes('/public/')) {
        handler.publicPage(req, res);
    } else if (req.url == '/search') {
        handler.handleSearch(req, res);
    }
    else {
        handler.pageNotFound(req, res);
    }
}
module.exports = router;