let searchimg = document.querySelector('.searchimg');
let buttonsearch = document.querySelector('.buttonsearch');

buttonsearch.addEventListener('submit', (event) => {
    event.preventDefault()
/////////////1. comm xhr with server//////////////////////////////
    request('/search', 'POST', searchimg.value, (err, res) => {//1. xhr sent to server (post=> to server) when click on btn (sent the endpound /search) 
        if (err) {
            // res.writeHead(404, { "content-Type": "text/html" });
            // res.end('error');
            console.log('error');
            
        } else {
            /////////////////////3. comm api with server ///////////////////
            const resApiReqServer = JSON.stringify(res);///this result from api into server that means the result body in server so this result is object because it is from api so that the server must convert to string
            //here inside myserver
            //now show the result in front
            //const resultFromServerToFront = JSON.parse(resApiReqServer);
            res.forEach(element => {
                
                const image = element.images.fixed_height_still.url;
                let tagimg = document.createElement('tagimg');
                tagimg.add.className('classtagimg')

                let taggimg = tagimg.setAttribute('src', image);
                let divimg = document.createElement('divimg');
                divimg.add.className('classdiv')
                divimg.appendChild(taggimg);
            });

        }
    })
})