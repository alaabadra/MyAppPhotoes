const test = require('tape');
const router = require('../src/router');
const supertest = require('supertest');
test('check status code is 200', (t) => {
  supertest(router)
    .get("/")
    .expect(200)
    .expect('Content-Type', /html/)
    .end((err, res) => {
      t.error(err)
      t.equal(res.headers['content-type'], 'text/html', 'response should contain homePage');
      t.end();
    });
});